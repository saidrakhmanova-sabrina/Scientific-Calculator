#include <iostream>

using namespace std;

void concentration() {
    int concentration_find_choice;
    cout<<"Concentration calculator. Choose what you need to find : \n 1. Moles \n 2. Molarity \n 3. Volume \n  ";
    cin>>concentration_find_choice;
    double m,mt,v;
    switch (concentration_find_choice) {
        case 1 :
        cout<<"You need to find Moles? \n";
        cout<<"Enter your molarity :\n";
        cin>>mt;
        cout<<"Enter your volume : \n";
        cin>>v;
        m = mt * v;
        cout<<"Moles :"<<m<<" mol \n";
        break ;
///////////////////////////////////////////////////////
        case 2 :
        cout<<"You need to find Molarity? \n";
        cout<<"Enter your moles :\n";
        cin>>m;
        cout<<"Enter your volume : \n";
        cin>>v;
        mt = m / v;;
        cout<<"Molarity :"<<mt<<" mol/L \n";
        break ;
        ///////////////////////////////////////
        case 3 :
        cout<<"You need to find Volume? \n";
        cout<<"Enter your moles :\n";
        cin>>m;
        cout<<"Enter your  molarity: \n";
        cin>>mt;
        v = m / mt;
        cout<<"Volume:"<<v<<"L \n";
        break ;



    }
    return;
}