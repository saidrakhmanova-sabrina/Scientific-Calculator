#include <iostream>

using namespace std;

void dilution() {
    int dilution_find_choice;
    cout<<"Dilution calculator. Choose what you need to find : \n 1. Final concentration \n 2. Initial concentration \n 3. Initial volume \n  4. Final volume \n ";
    cin>>dilution_find_choice;
    double fc,ic,iv,fv;
    switch (dilution_find_choice) {
        case 1 :
        cout<<"You need to find Final concentration? \n";
        cout<<"Enter your initial concentration :\n";
        cin>>ic;
        cout<<"Enter your initial volume : \n";
        cin>>iv;
        cout<<"Enter your final volume : \n";
        cin>>fv;
        fc = (ic * iv) / fv;
        cout<<" Final concentration : "<<fc<<"mol/L \n";
        break;
        ///////////////////////////////////////////////
        case 2 :
        cout<<"You need to find Initial concentration? \n";
        cout<<"Enter your final concentration :\n";
        cin>>fc;
        cout<<"Enter your initial volume : \n";
        cin>>iv;
        cout<<"Enter your final volume : \n";
        cin>>fv;
        ic = (fc * fv) / iv;
        cout<<" Initial concentration : "<<ic<<"mol/L \n";
        break;
        /////////////////////////////////////////////
        case 3 :
        cout<<"You need to find Initial volume? \n";
        cout<<"Enter your final concentration :\n";
        cin>>fc;
        cout<<"Enter your initial concentration : \n";
        cin>>ic;
        cout<<"Enter your final volume : \n";
        cin>>fv;
        iv = (fc * fv) / ic;
        cout<<" Initial volume : "<<iv<<"L or mL\n";
        break;
        ///////////////////////////////////////////////
        case 4 :
        cout<<"You need to find Final volume? \n";
        cout<<"Enter your final concentration :\n";
        cin>>fc;
        cout<<"Enter your initial concentration : \n";
        cin>>ic;
        cout<<"Enter your initial volume : \n";
        cin>>iv;
        fv = (ic * iv) / fc;
        cout<<" Final volume : "<<fv<<"L or mL\n";
        break;
}
return;
}