#include <iostream>

using namespace std;

void percentagecomposition(){
    int percentagecomposition_choose;
    cout<<"It is percentage composition calculator.\n";
    cout<<"What you need to find? \n 1. Total molar mass \n 2. Mass of element \n 3. Percent of an element \n ";
    cin>>percentagecomposition_choose;
    double p,mm,m;
    switch (percentagecomposition_choose) {
        case 1 :
        cout<<"You need to find Total molar mass? \n";
        cout<<"Enter your Mass of element :\n";
        cin>>m;
        cout<<"Enter your percent of an element : \n";
        cin>>p;
        mm = (m * 100) / p;
        cout<<"Total molar mass :"<<mm<<" g/mol \n";
        break ;
        /////////////////////
        case 2 :
        cout<<"You need to find Mass of element? \n";
        cout<<"Enter your Total molar mass :\n";
        cin>>mm;
        cout<<"Enter your percent of an element : \n";
        cin>>p;
        m = (p / 100) * mm;
        cout<<"Mass of element :"<<m<<" g \n";
        break ;
        //////////////////
        case 3 :
        cout<<"You need to find percent of an element? \n";
        cout<<"Enter your Total molar mass :\n";
        cin>>mm;
        cout<<"Enter your Mass of element : \n";
        cin>>m;
        p= (m / mm) * 100;
        cout<<"Percent of an element :"<<p<<" %\n";
        break ;
        
}
}