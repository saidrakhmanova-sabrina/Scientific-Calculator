#include <iostream>
#include <math.h>

using namespace std;

void kinematics() {
    int kinematics_choice;
    cout << "This is kinematics calculator!\n";
    cout << "Choose the law of kinematics : \n 1. 1st Law \n 2. 2nd Law \n 3. 3rd Law \n 4. 4th Law \n";
    cin >> kinematics_choice;

    double fv, iv, d, a, t;

  
    int kinematics_find_choose;

    switch (kinematics_choice) {
        case 1:
            cout << "What do you need to find? \n 1. Final velocity \n 2. Initial velocity \n 3. Acceleration \n 4. Time \n";
            cin >> kinematics_find_choose;
            if (kinematics_find_choose == 1) {
                cout << "You need to find Final velocity?\n";
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your acceleration:\n";
                cin >> a;
                cout << "Enter your time:\n";
                cin >> t;
                fv = iv + (a * t);
                cout << "Final velocity: " << fv << " m/s \n";
            }
            else if (kinematics_find_choose == 2) {
                cout << "You need to find Initial velocity?\n";
                cout << "Enter your final velocity:\n";
                cin >> fv;
                cout << "Enter your acceleration:\n";
                cin >> a;
                cout << "Enter your time:\n";
                cin >> t;
                iv = fv - (a * t);
                cout << "Initial velocity: " << iv << " m/s \n";
            }
            else if (kinematics_find_choose == 3) {
                cout << "You need to find Acceleration?\n";
                cout << "Enter your final velocity:\n";
                cin >> fv;
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your time:\n";
                cin >> t;
                a = (fv - iv) / t;
                cout << "Acceleration: " << a << " m/s^2 \n";
            }
            else {
                cout << "You need to find Time?\n";
                cout << "Enter your final velocity:\n";
                cin >> fv;
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your acceleration:\n";
                cin >> a;
                t = (fv - iv) / a;
                cout << "Time: " << t << " s \n";
            }
            break;

        case 2:
            cout << "What do you need to find? \n 1. Initial velocity \n 2. Displacement \n 3. Acceleration \n 4. Time \n";
            cin >> kinematics_find_choose;
            if (kinematics_find_choose == 1) {
                cout << "You need to find Initial velocity?\n";
                cout << "Enter your displacement:\n";
                cin >> d;
                cout << "Enter your acceleration:\n";
                cin >> a;
                cout << "Enter your time:\n";
                cin >> t;
                iv = (d - (0.5 * a * (t * t))) / t;
                cout << "Initial velocity: " << iv << " m/s \n";
            }
            else if (kinematics_find_choose == 2) {
                cout << "You need to find Displacement?\n";
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your acceleration:\n";
                cin >> a;
                cout << "Enter your time:\n";
                cin >> t;
                d = (iv * t) + (0.5 * a * (t * t));
                cout << "Displacement: " << d << " m \n";
            }
            else if (kinematics_find_choose == 3) {
                cout << "You need to find Acceleration?\n";
                cout << "Enter your displacement:\n";
                cin >> d;
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your time:\n";
                cin >> t;
                a = ((d - (iv * t) * 2)) / (t * t);
                cout << "Acceleration: " << a << " m/s^2 \n";
            }
            else {
                cout << "You need to find Time?\n";
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your displacement:\n";
                cin >> d;
                cout << "Enter your acceleration:\n";
                cin >> a;
                double t1 = (-iv + sqrt(iv * iv + 2 * a * d)) / a;
                double t2 = (-iv - sqrt(iv * iv + 2 * a * d)) / a;
                cout << "Time 1: " << t1 << " s\n";
                cout << "Time 2: " << t2 << " s\n";
            }
            break;

        case 3:
            cout << "What do you need to find? \n 1. Initial velocity \n 2. Displacement \n 3. Acceleration \n 4. Final velocity \n";
            cin >> kinematics_find_choose;
            if (kinematics_find_choose == 1) {
                cout << "You need to find Initial velocity?\n";
                cout << "Enter your final velocity:\n";
                cin >> fv;
                cout << "Enter your acceleration:\n";
                cin >> a;
                cout << "Enter your displacement:\n";
                cin >> d;
                iv = sqrt(fv * fv - 2 * a * d);
                cout << "Initial velocity: " << iv << " m/s \n";
            }
            else if (kinematics_find_choose == 2) {
                cout << "You need to find Displacement?\n";
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your acceleration:\n";
                cin >> a;
                cout << "Enter your final velocity:\n";
                cin >> fv;
                d = (fv * fv - iv * iv) / (2 * a);
                cout << "Displacement: " << d << " m \n";
            }
            else if (kinematics_find_choose == 3) {
                cout << "You need to find Acceleration?\n";
                cout << "Enter your displacement:\n";
                cin >> d;
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your final velocity:\n";
                cin >> fv;
                a = (fv * fv - iv * iv) / (2 * d);
                cout << "Acceleration: " << a << " m/s^2 \n";
            }
            else {
                cout << "You need to find Final velocity?\n";
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your displacement:\n";
                cin >> d;
                cout << "Enter your acceleration:\n";
                cin >> a;
                fv = sqrt(iv * iv + 2 * a * d);
                cout << "Final velocity: " << fv << " m/s \n";
            }
            break;

        case 4:
            cout << "What do you need to find? \n 1. Initial velocity \n 2. Displacement \n 3. Time \n 4. Final velocity \n";
            cin >> kinematics_find_choose;
            if (kinematics_find_choose == 1) {
                cout << "You need to find Initial velocity?\n";
                cout << "Enter your final velocity:\n";
                cin >> fv;
                cout << "Enter your time:\n";
                cin >> t;
                cout << "Enter your displacement:\n";
                cin >> d;
                iv = (2 * d / t) - fv;
                cout << "Initial velocity: " << iv << " m/s \n";
            }
            else if (kinematics_find_choose == 2) {
                cout << "You need to find Displacement?\n";
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your time:\n";
                cin >> t;
                cout << "Enter your final velocity:\n";
                cin >> fv;
                d = ((iv + fv) / 2) * t;
                cout << "Displacement: " << d << " m \n";
            }
            else if (kinematics_find_choose == 3) {
                cout << "You need to find Time?\n";
                cout << "Enter your displacement:\n";
                cin >> d;
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your final velocity:\n";
                cin >> fv;
                t = (2 * d) / (iv + fv);
                cout << "Time: " << t << " s \n";
            }
            else {
                cout << "You need to find Final velocity?\n";
                cout << "Enter your initial velocity:\n";
                cin >> iv;
                cout << "Enter your displacement:\n";
                cin >> d;
                cout << "Enter your time:\n";
                cin >> t;
                fv = (2 * d / t) - iv;
                cout << "Final velocity: " << fv << " m/s \n";
            }
            break;

        default:
            cout << "Invalid choice\n";
    }

    return;
}
