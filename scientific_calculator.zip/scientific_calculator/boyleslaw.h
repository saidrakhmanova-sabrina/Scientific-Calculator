#include <iostream>
#include <math.h>

using namespace std;

void boyleslaw(){
    int boyleslaw_find_choice;
    cout<<"Boyle's Law calculator. Choose what you need to find : \n 1. Initial pressure \n 2. Initial volume \n 3. Final pressure \n 4. Final volume \n ";
    cin>>boyleslaw_find_choice;
    double p1,p2,v1,v2;
    switch (boyleslaw_find_choice) {
        case 1 :
        cout<<"You need to find Initial pressure? \n";
        cout<<"Enter your Initial volume : \n";
        cin>>v1;
        cout<<"Enter your Final volume : \n";
        cin>>v2;
        cout<<"Enter your Final pressure : \n";
        cin>>p2;
        p1 = (p2 * v2) / v1;
        cout<<"Initial pressure :"<<p1<<"atm / Pa / mmHg \n";
        break;
        ///////////////////////////////////////
        case 2 :
        cout<<"You need to find Initial volume? \n";
        cout<<"Enter your Initial pressure : \n";
        cin>>p1;
        cout<<"Enter your Final volume : \n";
        cin>>v2;
        cout<<"Enter your Final pressure : \n";
        cin>>p2;
        v1 = (p2 * v2) / p1;
        cout<<"Initial volume :"<<v1<<"L/ mL \n";
        break;
        ///////////////////////////////////////
        case 3 :
        cout<<"You need to find Final pressure? \n";
        cout<<"Enter your Initial pressure : \n";
        cin>>p1;
        cout<<"Enter your Final volume : \n";
        cin>>v2;
        cout<<"Enter your Initial volume : \n";
        cin>>v1;
        p2 = (p1 * v1) / v2;
        cout<<"Final pressure :"<<p2<<" atm / Pa / mmHg \n";
        break;
        /////////////////////////////////////
        case 4 :
        cout<<"You need to find Final volume? \n";
        cout<<"Enter your Initial pressure : \n";
        cin>>p1;
        cout<<"Enter your Final pressure : \n";
        cin>>p2;
        cout<<"Enter your Initial volume : \n";
        cin>>v1;
        v2 = (p1 * v1) / p2;
        cout<<"Final volume :"<<v2<<" L/ mL \n";
        break;


    
}

return;
}