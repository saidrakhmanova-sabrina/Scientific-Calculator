#include <iostream>
#include <math.h>

using namespace std;

void phandpoh() {
    cout<<"This is pH and pOH calculator!\n";
    int pHandpOH_find_choice;
    cout<<"pH and pOH calculator. Choose what you need to find : \n 1. pH \n 2. pOH \n 3. Hydrogen ion concentration H+ \n  4. Hydroxide ion concentration OH- \n 5. pH from pOH \n 6.pOH from pH";
    cin>>pHandpOH_find_choice;
    double pH, pOH, H, OH;
    switch (pHandpOH_find_choice) {
        case 1 :
        cout<<"You need to find pH? \n";
        cout<<"Enter your Hydrogen ion concentration H+ \n";
        cin>>H;
        pH = -log10(H);
        cout<<"pH = "<<pH<<"\n";
        break;
        //////////////////////////////////
        case 2 :
        cout<<"You need to find pOH? \n";
        cout<<"Enter your Hydroxide ion concentration [OH-] \n";
        cin>>OH;
        pOH = -log10(OH);
        cout<<"pOH = "<<pOH<<"\n";
        break;
        /////////////////////////////////
        case 3 :
        cout<<"You need to find Hydrogen Ion concentration? \n";
        cout<<"Enter your pH \n";
        cin>>pH;
        H = pow(10, -pH);
        cout<<"Hydrogen ion concentration [H+] = "<<H<<"\n";
        break;
        ///////////////////////////////
        case 4 :
        cout<<"You need to find Hydroxide Ion concentration? \n";
        cout<<"Enter your pOH \n";
        cin>>pOH;
        OH = pow(10, -pOH);
        cout<<"Hydroxide ion concentration [OH-] = "<<OH<<"\n";
        break;
        //////////////////////////////
        case 5 :
        cout<<"You need to find pH from pOH? \n";
        cout<<"Enter your pOH \n";
        cin>>pOH;
        pH = 14 - pOH;
        cout<<"pH = "<<pH<<"\n";
        break;
        ///////////////////////////////
        case 6 :
        cout<<"You need to find pOH from pH? \n";
        cout<<"Enter your pH \n";
        cin>>pH;
        pOH = 14 - pH;
        cout<<"pOH = "<<pOH<<"\n";
        break;}

    return;
}