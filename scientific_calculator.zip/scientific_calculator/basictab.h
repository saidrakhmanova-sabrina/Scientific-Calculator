#include <iostream>
#include <sstream>

using namespace std; 

void basictab() {
    string input;
    
    cout << "Enter a mathematical expression (or type 'exit' to quit):\n";
    
    while (true) {
        cout << "> ";
        getline(cin, input);

        if (input == "exit") break; 

        stringstream ss(input);
        double num, result;
        char op;

        ss >> result; 

        while (ss >> op >> num) { 
            if (op == '+') result += num;
            else if (op == '-') result -= num;
            else if (op == '*') result *= num;
            else if (op == '/') {
                if (num == 0) {
                    cout << "Error: Division by zero!\n";
                    break;
                }
                result /= num;
            } else {
                cout << "Invalid operator: " << op << "\n";
                break;
            }
        }

        cout << "Result: " << result << "\n";
    }
    
    cout << "Calculator exited.\n";
    return 0;
}
