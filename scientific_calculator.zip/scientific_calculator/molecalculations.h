#include <iostream>

using namespace std;

void molecalculations() {
    int molecalculations_find_choice;
    cout<<"Moles calculator. Choose what you need to find : \n 1. Moles \n 2. Mass \n 3. Molar mass \n  ";
    cin>>molecalculations_find_choice;
    double n,m,M;
    switch (molecalculations_find_choice) {
        case 1 :
        cout<<"You need to find Moles? \n";
        cout<<"Enter your mass :\n";
        cin>>m;
        cout<<"Enter your molar mass : \n";
        cin>>M;
        n = m/M;
        cout<<"Moles :"<<n<<" mol \n";
        break ;
///////////////////////////////////////////////////////
        case 2 :
        cout<<"You need to find Mass? \n";
        cout<<"Enter your moles :\n";
        cin>>n;
        cout<<"Enter your molar mass : \n";
        cin>>M;
        m = n *M;
        cout<<"Mass :"<<m<<" grams \n";
        break ;
        ///////////////////////////////////////
        case 3 :
        cout<<"You need to find Molar Mass? \n";
        cout<<"Enter your moles :\n";
        cin>>n;
        cout<<"Enter your  mass : \n";
        cin>>m;
        M = m / n; 
        cout<<"Molar Mass :"<<M<<" g/mol \n";
        break ;



    }
    return;
}