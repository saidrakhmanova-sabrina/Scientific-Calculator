#include <iostream>

using namespace std;
void sdt() {
    cout<<"This is speed, distance and time calculator!\n";
    int std_find_choice;
    cout<<"Speed , Distance and Time calculator. Choose what you need to find : \n 1. Speed \n 2. Distance \n 3. Time ";
    cin>>std_find_choice;
    switch (std_find_choice) {
        double t,d,s;
        case 1 :
        cout<<"You need to find Speed?\n";
        cout<<"Enter your distance\n";
        cin>>d;
        cout<<"Enter your time\n ";
        cin>>t;
        s = d/t;
        cout<<"Speed :"<<s<<" km/h\n";
        break ;
        case 2 :
        cout<<"You need to find Distance?\n";
        cout<<"Enter your speed\n";
        cin>>s;
        cout<<"Enter your time\n ";
        cin>>t;
        d =  s*t;
        cout<<"Distance :"<<d<<" km\n";
        break ;
        case 3 :
        cout<<"You need to find Time?\n";
        cout<<"Enter your speed\n";
        cin>>s;
        cout<<"Enter your distance\n ";
        cin>>d;
        t =  d/s;
        cout<<"Time :"<<t<<" h \n";
        break ;
        



    }
    return;
}
