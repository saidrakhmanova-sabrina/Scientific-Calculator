#include <iostream>

using namespace std;

void pressure() {
    cout<<"This is pressure calculator!\n";
    int pressure_find_choice;
    cout<<"Pressure calculator. Choose what you need to find : \n 1. Force  \n 2. Area \n 3. Pressure ";
    cin>>pressure_find_choice;
    switch (pressure_find_choice) {
        double f,a,p;
        case 1 :
        cout<<"You need to find Force?\n";
        cout<<"Enter your area\n";
        cin>>a;
        cout<<"Enter your pressure\n ";
        cin>>p;
        f = p*a;
        cout<<"Force  :"<<f<<"N\n";
        break ;
        case 2 :
        cout<<"You need to find Area?\n";
        cout<<"Enter your force\n";
        cin>>f;
        cout<<"Enter your pressure\n ";
        cin>>p;
        a = f/p;
        cout<<"Area :"<<a<<"m^2\n";
        break ;
        case 3 :
        cout<<"You need to find Pressure?\n";
        cout<<"Enter your force\n";
        cin>>f;
        cout<<"Enter your area\n ";
        cin>>a;
        p =  f/a;
        cout<<" Pressure :"<<p<<"pascal\n";
        break ;
        



    }
    return;
}