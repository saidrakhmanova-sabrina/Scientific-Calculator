#include <iostream>
#include <thread>

#include "molecalculations.h"
#include "boyleslaw.h"
#include "charleslaw.h"
#include "concentration.h"
#include "dilution.h"
#include "kinematics.h"
#include "ohmslaw.h"
#include "percentagecomposition.h"
#include "phandpoh.h"
#include "pressure.h"
#include "sdt.h"



using namespace std;

int main() {
    while (true) {
    int subject_choice, calculator_choice;
    cout << "Welcome to scientific calculator! \n";
    cout << "Choose the subject : \n 1. Physics \n 2. Chemistry \n";
    cin >> subject_choice;

    if (subject_choice == 1) {
        cout << "Physics is a great choice! \nChoose what calculator you need : \n";
        cout << "1. Speed - Distance - Time \n2. Pressure \n3. Ohm's Law \n4. Kinematics \n";
        cin >> calculator_choice;

        switch (calculator_choice) {
            case 1:
                sdt(); 
                break;
            case 2:
                pressure(); 
                break;
            case 3:
                ohmslaw(); 
                break;
            case 4:
                kinematics(); 
                break;
            default:
                cout << "Invalid calculator choice.\n";
        }
    }

    else {
        cout << "Chemistry is a great choice! \nChoose what calculator you need : \n";
        cout << "1. pH and pOH \n2. Percentage composition \n3. Mole calculations \n4. Dilution \n 5.Concentration \n 6.Charles's Law \n 7.Boyle's Law \n ";
        cin >> calculator_choice;

        switch (calculator_choice) {
            case 1:
                phandpoh(); 
                break;
            case 2:
                percentagecomposition(); 
                break;
            case 3:
                molecalculations(); 
                break;
            case 4:
                dilution(); 
                break;
            case 5:
                concentration();
                break;
            case 6:
                charleslaw();
                break;
            case 7 :
                boyleslaw();
                break;
            default:
                cout << "Invalid calculator choice.\n";
        }

    }
}


    return 0;
}
