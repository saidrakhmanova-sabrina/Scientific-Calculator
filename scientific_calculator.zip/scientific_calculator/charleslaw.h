#include <iostream>
#include <math.h>

using namespace std;

void charleslaw(){
    int charleslaw_find_choice;
    cout<<"Charles's Law calculator. Choose what you need to find : \n 1. Initial temperature \n 2. Initial volume \n 3. Final temperature \n  4.Final volume \n ";
    cin>>charleslaw_find_choice;
    double v1,v2,t1,t2;
    switch (charleslaw_find_choice) {
        case 1 :
        cout<<"You need to find Initial temperature? \n";
        cout<<"Enter your Initial volume : \n";
        cin>>v1;
        cout<<"Enter your Final volume : \n";
        cin>>v2;
        cout<<"Enter your Final temperature : \n";
        cin>>t2;
        t1 = (t2 * v1) / v2;
        cout<<"Initial temperature  :"<<t1<<" K \n";
        break;
        ///////////////////////////////////////
        case 2 :
        cout<<"You need to find Initial volume? \n";
        cout<<"Enter your Initial temperature : \n";
        cin>>t1;
        cout<<"Enter your Final volume : \n";
        cin>>v2;
        cout<<"Enter your Final temperature : \n";
        cin>>t2;
        v1 = (v2 * t1) / t2;
        cout<<"Initial volume :"<<v1<<"L/ mL \n";
        break;
        ///////////////////////////////////////
        case 3 :
        cout<<"You need to find Final temperature? \n";
        cout<<"Enter your Initial temperature : \n";
        cin>>t1;
        cout<<"Enter your Final volume : \n";
        cin>>v2;
        cout<<"Enter your Initial volume : \n";
        cin>>v1;
        t2 = (t1 * v2) / v1;
        cout<<"Final temperature:"<<t2<<" K \n";
        break;
        /////////////////////////////////////
        case 4 :
        cout<<"You need to find Final volume? \n";
        cout<<"Enter your Initial temperature : \n";
        cin>>t1;
        cout<<"Enter your Final temperature : \n";
        cin>>t2;
        cout<<"Enter your Initial volume : \n";
        cin>>v1;
        v2 = (v1 * t2) / t1;
        cout<<"Final volume :"<<v2<<" L/ mL \n";
        break;


    
}

return;
}